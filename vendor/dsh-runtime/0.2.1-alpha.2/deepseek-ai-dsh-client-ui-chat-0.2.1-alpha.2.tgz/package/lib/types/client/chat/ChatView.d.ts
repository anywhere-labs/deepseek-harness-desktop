import type { ChatViewSlotProps } from '../contract/slots.ts';
/**
 * The chat view slot entry: pure component over the composed props; each
 * ordered business Node crosses the keyed renderer seat.
 */
export declare function ChatView({ useSession, useChat, useConversation, useSessions, renderSlot, sessionId, openFile, openSkill, openExternalLink, loadOlder, loadThrough, loadImage, inspectCall, chatScroll, forkAt, fileMentions, usePresentation, useProjection, t, }: ChatViewSlotProps): import("react").JSX.Element;
//# sourceMappingURL=ChatView.d.ts.map