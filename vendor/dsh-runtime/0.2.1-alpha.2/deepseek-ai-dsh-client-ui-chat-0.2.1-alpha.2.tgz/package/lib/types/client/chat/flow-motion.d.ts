/**
 * Fade-then-close transitions owned by one Chat viewport. Rows fade before their boxes close;
 * the owner reserves removed height and holds scrolling until that viewport's folds finish.
 * Motion is opt-in under `[data-chat-motion]`, respects reduced motion, and clears temporary styles.
 */
import { type RefObject } from 'react';
/** Row-local operations supplied by the containing viewport. */
export interface FlowMotionRows {
    /** @param element - visible row. @param done - commits hidden state before idle callbacks run. */
    collapse(element: HTMLElement, done: () => void): void;
    /** @param element - newly visible row to grow to its natural size. */
    reveal(element: HTMLElement): void;
    /** @param element - row whose active transition should be cancelled without hiding it. */
    cancelMotion(element: HTMLElement): void;
}
/** Animation lifetime and fold coordination for one viewport. */
export interface FlowMotion extends FlowMotionRows {
    /** @returns whether a row owned by this viewport is closing. */
    foldActive(): boolean;
    /** @param listener - callback after the last fold. @returns cancellation for a pending callback. */
    onFoldIdle(listener: () => void): () => void;
    /** Cancel owned animations and pending work when the viewport detaches. */
    clear(): void;
}
/**
 * Decide whether a row may animate: inside a live scope and not under reduced motion.
 * @param element - row about to be hidden.
 * @returns whether the fade-then-close transition applies.
 */
export declare function motionEnabled(element: HTMLElement): boolean;
/**
 * Whether a row is already hidden or on its way there.
 * @param element - row under Turn-level visibility control.
 * @returns hidden attribute present or a collapse transition outstanding.
 */
export declare function hiddenOrCollapsing(element: HTMLElement): boolean;
/**
 * Create animation coordination without cross-viewport broadcasts.
 * @param reserve - reserve the deduplicated removed height in this viewport.
 * @param foldingChanged - disable or restore this viewport's native scroll anchoring.
 * @returns stable callbacks and cleanup for this viewport's animations.
 */
export declare function createFlowMotion(reserve: (px: number) => void, foldingChanged: (active: boolean) => void): FlowMotion;
/**
 * Apply searchable hiding with the containing Chat viewport's optional fold animation.
 * @param hidden - desired visibility.
 * @param reveal - browser-find and focus-protection callback.
 * @param motion - owning viewport's row callbacks; undefined applies visibility synchronously.
 * @returns the stable subtree ref.
 */
export declare function useFlowHidden(hidden: boolean, reveal: () => void, motion: FlowMotionRows | undefined): RefObject<HTMLDivElement>;
/**
 * Toggle a plain hidden attribute on the fold clock, growing newly revealed headers.
 * @param ref - element whose visibility follows hidden.
 * @param hidden - desired hidden state.
 * @param motion - containing viewport's row callbacks.
 */
export declare function useMotionHidden(ref: RefObject<HTMLElement | null>, hidden: boolean, motion: FlowMotionRows): void;
//# sourceMappingURL=flow-motion.d.ts.map