/** Web dictionaries for the chrome around a mod's band; the mods' own content is theirs. */
/** Locale namespace owned by the mods band. */
export declare const NS = "claude-code-mods";
/** Simplified Chinese dictionary and key source. */
export declare const zh: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
/** Mods band locale key union. */
export type ModsBandKey = keyof typeof zh;
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    band: string;
    pressing: string;
    'press.failed': string;
    'press.stale': string;
};
//# sourceMappingURL=locales.d.ts.map