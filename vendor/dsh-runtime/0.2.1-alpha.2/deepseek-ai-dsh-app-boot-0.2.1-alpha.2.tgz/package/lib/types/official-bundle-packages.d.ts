/** Package admission shared by offline catalog generation and release ordering. */
/** Public DSH release members available through the ordinary on-demand bundle installer. */
export declare const ON_DEMAND_BUNDLES: readonly string[];
//# sourceMappingURL=official-bundle-packages.d.ts.map