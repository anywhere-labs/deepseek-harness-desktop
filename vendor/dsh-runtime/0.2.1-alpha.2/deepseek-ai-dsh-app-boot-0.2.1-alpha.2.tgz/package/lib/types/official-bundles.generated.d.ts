/** Generated offline Official bundle metadata. Run pnpm gen-official-bundle-catalog; do not edit. */
import type { OfficialBundleCatalogEntry } from './official-bundles.ts';
/** Official on-demand entries, independent of installed packages and registry availability. */
export declare const OFFICIAL_ON_DEMAND_CATALOG: readonly OfficialBundleCatalogEntry[];
//# sourceMappingURL=official-bundles.generated.d.ts.map