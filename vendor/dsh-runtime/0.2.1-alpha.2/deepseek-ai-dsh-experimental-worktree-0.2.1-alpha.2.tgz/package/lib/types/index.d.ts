/** Creates a new Git branch and checkout, then changes the calling Session's working directory. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { CreatedWorktree, CreateWorktreeRequest } from './types.ts';
export type { CreatedWorktree, CreateWorktreeRequest } from './types.ts';
/** Worktree location, generated names, executables, and subprocess resource limits. */
export interface Config {
    /** Relative checkout pool inside the source repository. */
    directory?: string;
    /** Prefix for automatically generated branch and checkout names. */
    namePrefix?: string;
    /** Git 2.45 or newer executable name or absolute execution-world path. */
    gitCommand?: string;
    /** Node executable used for sandboxed directory allocation. */
    nodeCommand?: string;
    /** Deadline in milliseconds for one command. */
    timeoutMs?: number;
    /** Subprocess termination grace in milliseconds. */
    graceMs?: number;
    /** Maximum captured bytes per subprocess output stream. */
    maxOutputBytes?: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        worktrees: WorktreeService;
    }
}
/** Creates retained Git worktrees under the mounted filesystem and sandbox providers. */
export declare class WorktreeService extends Service {
    static inject: string[];
    static Config: z<Config>;
    private readonly config;
    private readonly lifetime;
    private readonly pending;
    constructor(ctx: Context, config: Config);
    /**
     * Create a fresh branch and checkout at a pinned local revision, then enter it.
     * Existing branches or checkout paths fail. Uncommitted files stay in the source checkout.
     * Checkout disables configured clean, smudge, and process filters without changing Git config.
     * Repository-local replacement refs still apply; baseCommit reports the resolved object name.
     * The new checkout becomes current only after Git setup succeeds. Failures may retain newly
     * allocated Git/filesystem artifacts; no branch or checkout is removed automatically.
     * @param agent - caller whose current directory selects the source repository and file policy.
     * @param request - optional new name and local revision; defaults are generated name and HEAD.
     * @param signal - cancellation of lookup, creation, and working-directory publication.
     * @returns canonical checkout path, branch name, pinned commit, and source repository root.
     */
    create(agent: Agent, request?: CreateWorktreeRequest, signal?: AbortSignal): Promise<CreatedWorktree>;
    private resolve;
    private createCheckout;
}
export default WorktreeService;
//# sourceMappingURL=index.d.ts.map