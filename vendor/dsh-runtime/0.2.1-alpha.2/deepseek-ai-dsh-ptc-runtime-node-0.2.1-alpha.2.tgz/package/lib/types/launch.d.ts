import type { FileSystem } from '@deepseek-ai/dsh-fs';
/** Deployment-owned worker invocation in the subprocess execution world. */
export type LaunchConfig = {
    /** Start a separately installed Node executable and JavaScript bootstrap. */
    kind: 'node-script';
    /** Executable name or path resolved by the subprocess provider. */
    executable: string;
    /** Absolute preinstalled bootstrap; omitted maps this package's bootstrap into the execution world. */
    bootstrapPath?: string;
} | {
    /** Start the private PTC worker embedded in a packaged executable. */
    kind: 'embedded';
    /** Packaged executable name or path resolved by the subprocess provider. */
    executable: string;
};
/**
 * Resolve the local carrier default or validate an explicit execution-world invocation.
 * @param config - explicit remote or local worker configuration; omitted selects this carrier.
 * @returns the worker invocation without guessing from the execution world's paths.
 */
export declare function resolveLaunch(config?: LaunchConfig): LaunchConfig;
/**
 * Select explicit arguments without inheriting host loader or inspector flags.
 * @param fs - Filesystem mapping host bootstrap assets into the process world.
 * @param config - resolved worker invocation.
 * @param maxMessageBytes - Validated frame and queued-write limit.
 * @returns Arguments following the resolved Node executable.
 */
export declare function bootstrapArgs(fs: Pick<FileSystem, 'processPathFromHostPath'>, config: LaunchConfig, maxMessageBytes: number): string[];
//# sourceMappingURL=launch.d.ts.map