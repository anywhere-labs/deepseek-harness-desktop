/** Locale-owned messages shared by microphone preview and dictation. */
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/**
 * Translate a capture or transcription failure.
 * @param failure - the rejected value.
 * @param t - the active voice-input translator.
 * @returns localized failure text.
 */
export declare function failureText(failure: unknown, t: PropsLocale<typeof NS>['t']): string;
//# sourceMappingURL=failure-text.d.ts.map