/**
 * Result-time contextual diff presentation for write and edit. Storage returns before/after
 * text; this model-facing layer derives one three-line-context card per applied hunk.
 * @module @deepseek-ai/dsh-tool-fs/src/diff
 */
import type { FileDiff } from '@deepseek-ai/dsh-tools';
/** Context lines shown on each side of an applied hunk. */
export declare const DIFF_CONTEXT = 3;
/**
 * The `write`/`edit` tools' private `tool/result` `meta` payload: the applied
 * contextual-diff hunks, and for `write` whether the call created or updated
 * the file, which tells an empty hunk list of a create from one of an
 * unchanged overwrite. Attached opaquely (as `unknown`) on the tool result and
 * persisted with the session log — it must be JSON-serializable (the session
 * validates this at `append`), so `presentResult` reproduces the diff card on
 * replay. The producing tool owns and narrows this opaque shape.
 */
export type FsDiffMeta = {
    diffs: FileDiff[];
    operation?: 'create' | 'update';
};
/**
 * Compute one {@link FileDiff} per hunk between `before` and `after`, each carrying the
 * applied change plus {@link DIFF_CONTEXT} context lines. Pure insertions use `oldText: null`,
 * patch-only no-newline markers are omitted, and scattered replacements remain separate hunks.
 *
 * @param path - the path stamped on every produced diff (the model-facing `file_path`; the
 *   bridge relativizes it).
 * @param before - the file text before the change (the backend's LF-normalized diff basis).
 * @param after - the file text after the change, on the same basis.
 * @returns one diff per applied hunk, in file order; empty when the texts are identical.
 */
export declare function computeHunkDiffs(path: string, before: string, after: string): FileDiff[];
/**
 * Narrow opaque live or replayed result metadata to non-empty file diffs. Malformed metadata
 * returns `undefined` so presentation can fall back instead of throwing during replay.
 * @param meta - result metadata.
 * @returns validated hunks, or `undefined` for absent or malformed data.
 */
export declare function diffsFromMeta(meta: unknown): FileDiff[] | undefined;
/**
 * Read the operation's file path even when the applied diff is empty.
 * @param meta - opaque persisted result metadata.
 * @returns the recorded path, or undefined for old or malformed metadata.
 */
export declare function pathFromMeta(meta: unknown): string | undefined;
//# sourceMappingURL=diff.d.ts.map