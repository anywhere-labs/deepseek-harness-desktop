/**
 * JSON-RPC methods and notifications for out-of-process harness SDKs.
 * The surrounding context owns plugins, persistence, and configured adapters.
 *
 * @module @deepseek-ai/dsh-sdk-jsonrpc-server/server
 */
import type { Context } from '@deepseek-ai/cordis';
import type { InitializeParams, InitializeResult, JsonRpcTransportPeer, SessionPromptParams, SessionPromptResult, SessionWaitParams, SessionWorkingDirectoryParams, SessionWorkingDirectorySetParams, SessionWorkingDirectoryResult } from '@deepseek-ai/dsh-sdk-protocol';
/** Deployment-specific status mapping for SDK turn and subagent outcomes. */
export interface HarnessSdkJsonRpcServerOptions {
    /** Report max-token termination as an accepted result instead of an infrastructure error. */
    maxTokensAsSuccess?: boolean;
}
/**
 * SDK server over one booted harness context and transport peer. Construction
 * subscribes to session, agent, and subagent lifecycle events until shutdown;
 * reinitialization is unsupported.
 */
export declare class HarnessSdkJsonRpcServer {
    private readonly ctx;
    private readonly transport;
    private readonly options;
    private cwd;
    private provider;
    private model;
    private reasoningEffort;
    private maxTokens;
    private llmFiber;
    private readonly sessions;
    private readonly sessionCreations;
    private readonly disposers;
    private shutdownTask;
    private shuttingDown;
    private initialized;
    constructor(ctx: Context, transport: JsonRpcTransportPeer, options?: HarnessSdkJsonRpcServerOptions);
    /**
     * Validate and configure the SDK route, mounting the DeepSeek fallback only when unowned.
     * @param params - SDK handshake parameters.
     * @returns server identity for the handshake.
     */
    initialize(params: InitializeParams): Promise<InitializeResult>;
    /**
     * Queue one identified prompt without assigning later activity to it.
     * @param params - target session and user content.
     * @returns the durable message identity.
     */
    prompt(params: SessionPromptParams): Promise<SessionPromptResult>;
    /**
     * Wait for an existing owned Agent and its managed descendants to finish.
     * The response follows all Session notifications emitted during the wait.
     * Rejects a live Agent failure that has no subsequent durable terminal.
     * @param params - the SDK-owned session to observe without creating one.
     * @returns an empty result after the root stays idle across the descendant check.
     */
    wait(params: SessionWaitParams): Promise<Record<string, never>>;
    private assertLiveAgent;
    /**
     * Read a Session's effective directory, recovering a missing directory to its origin.
     * @param params - target Session; an unknown id creates it.
     * @returns the absolute effective directory.
     */
    getWorkingDirectory(params: SessionWorkingDirectoryParams): Promise<SessionWorkingDirectoryResult>;
    /**
     * Change a Session's directory and queue its model-visible transition.
     * @param params - target Session and absolute or current-directory-relative path.
     * @returns the validated absolute directory; origin and permissions are unchanged.
     */
    setWorkingDirectory(params: SessionWorkingDirectorySetParams): Promise<SessionWorkingDirectoryResult>;
    private workingDirectoryAgent;
    /**
     * Dispose server-owned agents, adapter, and subscriptions to quiescence.
     * Managed descendants drain before the root Agent handles and adapter are released.
     * The surrounding context remains running.
     * @returns empty JSON-RPC result.
     */
    shutdown(): Promise<Record<string, never>>;
    private performShutdown;
    /**
     * Dispatch one incoming JSON-RPC request to its typed handler. Throws (→ a
     * JSON-RPC error response) on an unknown method.
     * @param method - the JSON-RPC method name.
     * @param params - the raw params object from the wire.
     * @returns the handler's result, to be serialized as the response.
     */
    handleRequest(method: string, params: Record<string, unknown> | undefined): Promise<unknown>;
    private getOrCreateSession;
    private createSession;
    private hasAdapterFor;
}
//# sourceMappingURL=server.d.ts.map