import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { SubmittedPlan } from './plan.ts';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ToolCallId } from '@deepseek-ai/dsh-llm/brand';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { createPlanReviewStore } from './review-store.ts';
/** Session-bound navigation for logged plans. */
export interface PlanOpenInjected {
    /** Open or focus the exact submitted plan. */
    openPlan: (callId: ToolCallId) => void;
}
/** Turn-keyed submitted plans and Session-bound navigation. */
export interface PlanCardsInjected extends PlanOpenInjected {
    keyedHooks: {
        /** Resolve only this Turn's submitted plans, in invocation order. */
        plans: (turn: string) => ObservableSnapshot<readonly SubmittedPlan[]>;
    };
}
/** Session-bound preview navigation for one pending review. */
export interface PlanReviewOpenInjected {
    /** Open the logged plan, or the request's temporary document when no invocation exists. */
    openReview: (review: PropsRuntime<'conversation.plan-review.actions'>['review'], requestKey: string) => void;
    readonly hooks: {
        /** The Session on screen, whose right Sidebar the opens land in; `undefined` while none is. */
        readonly sidebarMounted: HostObservable<SessionId | undefined>;
    };
}
/**
 * Render the completed Turn's submitted plans in invocation order.
 * @param props - Logged plan, localized copy, and Session-bound navigation.
 * @returns keyboard-accessible plan cards, or null for a Turn without plans.
 */
export declare function PlanCards({ turn, usePlans, openPlan, t }: PropsRuntime<'conversation.chat.turnTail'> & InjectFace<PlanCardsInjected> & PropsLocale<'plan'>): import("react").JSX.Element | null;
/**
 * Open each pending plan automatically and retain a manual opener without answering it.
 *
 * The automatic open waits for a Session on screen. `ctx.sidebarRight` names
 * the Session before the commit that brings its Conversation back renders, so
 * a review that arrived while the Conversation was off screen opens from the
 * effect of the commit that mounts it.
 * @param props - Review identity, Session store, localized copy, and navigation.
 * @returns an opener for either logged or temporary plan text.
 */
export declare function PlanReviewOpen({ review, requestKey, openReview, useSidebarMounted, t, useStore, actions }: PropsRuntime<'conversation.plan-review.actions'> & InjectFace<PlanReviewOpenInjected> & PropsLocale<'plan'> & PropsStore<ReturnType<typeof createPlanReviewStore>>): import("react").JSX.Element;
//# sourceMappingURL=PlanCard.d.ts.map