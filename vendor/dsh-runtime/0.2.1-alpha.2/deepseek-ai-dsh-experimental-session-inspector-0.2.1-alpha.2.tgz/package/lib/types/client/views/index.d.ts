/** Session-scoped Sidebar tab backed by the existing Chat and Session-log models. */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the Session Inspector Sidebar page and its Session-scoped sources.
 * @param ctx - Client plugin context owning the tab registration and Session-bound model cache.
 */
export declare function registerInspectorTab(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map