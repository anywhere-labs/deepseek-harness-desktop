export type { CotTranslationPreferences, CotTranslationSnapshot } from './types.ts';
/** Language preference accepted by both Host configuration and browser drafts. */
export declare const LANGUAGE_PREFERENCE_PATTERN: RegExp;
/** Explicit provider choices accepted by Host configuration and browser drafts. */
export declare const PROVIDER_PREFERENCES: readonly ["bing", "google", "deepseek-account", "deepseek-official"];
//# sourceMappingURL=preferences.d.ts.map