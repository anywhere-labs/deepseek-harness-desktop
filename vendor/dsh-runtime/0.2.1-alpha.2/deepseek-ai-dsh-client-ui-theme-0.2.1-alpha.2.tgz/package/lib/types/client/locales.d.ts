/** `settings.theme` namespace dictionaries (the Appearance and font settings rows' copy). */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'appearance.title': string;
    'appearance.light': string;
    'appearance.dark': string;
    'appearance.system': string;
    'fontSize.text.title': string;
    'fontSize.text.description': string;
    'fontSize.text.increase': string;
    'fontSize.text.decrease': string;
    'fontSize.code.title': string;
    'fontSize.code.description': string;
    'fontSize.code.increase': string;
    'fontSize.code.decrease': string;
    'fontSize.terminal.title': string;
    'fontSize.terminal.description': string;
    'fontSize.terminal.increase': string;
    'fontSize.terminal.decrease': string;
    'fontSize.unit': string;
    'fontFamily.text.title': string;
    'fontFamily.text.description': string;
    'fontFamily.code.title': string;
    'fontFamily.code.description': string;
    'fontFamily.terminal.title': string;
    'fontFamily.terminal.description': string;
    'fontFamily.placeholder': string;
    'fontSize.more': string;
};
/** The settings.theme namespace key union. */
export type ThemeKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'appearance.title': string;
    'appearance.light': string;
    'appearance.dark': string;
    'appearance.system': string;
    'fontSize.text.title': string;
    'fontSize.text.description': string;
    'fontSize.text.increase': string;
    'fontSize.text.decrease': string;
    'fontSize.code.title': string;
    'fontSize.code.description': string;
    'fontSize.code.increase': string;
    'fontSize.code.decrease': string;
    'fontSize.terminal.title': string;
    'fontSize.terminal.description': string;
    'fontSize.terminal.increase': string;
    'fontSize.terminal.decrease': string;
    'fontSize.unit': string;
    'fontFamily.text.title': string;
    'fontFamily.text.description': string;
    'fontFamily.code.title': string;
    'fontFamily.code.description': string;
    'fontFamily.terminal.title': string;
    'fontFamily.terminal.description': string;
    'fontFamily.placeholder': string;
    'fontSize.more': string;
};
//# sourceMappingURL=locales.d.ts.map